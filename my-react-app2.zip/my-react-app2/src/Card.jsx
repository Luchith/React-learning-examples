import profilePic from './assets/myimg.jpg'
function Card() {
  return (
    <div className="card">
      <img src={profilePic} alt="profile picture"></img>
      <h2>Luchith Code</h2>
      <p>I Develop websites and play cricket</p>
    </div>
  );
}
export default Card;
